import cv2
import mediapipe as mp
import time

class handDetector:
    """
    A class for detecting and tracking hands using MediaPipe.

    Attributes:
        mode (bool): Whether to treat input images as a batch of static images or a video stream.
        maxHands (int): Maximum number of hands to detect.
        detectionCon (float): Minimum detection confidence threshold.
        trackCon (float): Minimum tracking confidence threshold.
    """

    def __init__(self, mode=False, maxHands=2, detectionCon=0.5, trackCon=0.5):
        """
        Initializes the hand detection model with specified parameters.
        """
        self.mode = mode
        self.maxHands = maxHands
        self.detectionCon = detectionCon
        self.trackCon = trackCon

        # Initialize MediaPipe Hands module
        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(
            static_image_mode=self.mode,
            max_num_hands=self.maxHands,
            min_detection_confidence=self.detectionCon,
            min_tracking_confidence=self.trackCon
        )

        # Utility for drawing landmarks
        self.mpDraw = mp.solutions.drawing_utils

    def findHands(self, img, draw=True):
        """
        Detects hands in the given image and optionally draws the landmarks.

        Args:
            img (ndarray): The input image from webcam.
            draw (bool): Whether to draw hand landmarks on the image.

        Returns:
            img (ndarray): Image with or without hand landmarks drawn.
        """
        # Convert image to RGB for MediaPipe processing
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)

        # If hands are detected, draw landmarks
        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, self.mpHands.HAND_CONNECTIONS)

        return img

    def findPosition(self, img, handNo=0, draw=True):
        """
        Extracts and optionally draws the position of hand landmarks.

        Args:
            img (ndarray): The input image.
            handNo (int): The index of the hand to track (0 for the first hand).
            draw (bool): Whether to draw circles on the landmarks.

        Returns:
            lmList (list): A list of landmarks as [id, x, y].
        """
        lmList = []

        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]

            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)  # Convert to pixel coordinates
                lmList.append([id, cx, cy])

                if draw:
                    cv2.circle(img, (cx, cy), 7, (255, 0, 255), cv2.FILLED)

        return lmList


def main():
    """
    Main function to test real-time hand tracking.
    Displays FPS and prints position of landmark 4 (tip of the thumb).
    """
    pTime = 0
    cTime = 0

    # Capture video from webcam (change 0 if using external camera)
    cap = cv2.VideoCapture(0)

    # Create a hand detector object
    detector = handDetector()

    while True:
        # Read a frame from the webcam
        success, img = cap.read()

        # Detect hands and draw landmarks
        img = detector.findHands(img)

        # Get list of hand landmarks
        lmList = detector.findPosition(img)

        # If landmarks are detected, print the position of landmark 4
        if len(lmList) != 0:
            print(lmList[4])  # Example: Tip of thumb

        # Calculate and display FPS
        cTime = time.time()
        fps = 1 / (cTime - pTime)
        pTime = cTime

        cv2.putText(img, str(int(fps)), (10, 70), cv2.FONT_HERSHEY_PLAIN, 3,
                    (255, 0, 255), 3)

        # Show the image
        cv2.imshow("Image", img)
        cv2.waitKey(1)


# Run the script only if it's the main module
if __name__ == "__main__":
    main()
