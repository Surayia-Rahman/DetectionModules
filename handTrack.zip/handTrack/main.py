import cv2
import mediapipe as mp
import time

# Initialize webcam
cap = cv2.VideoCapture(0)

# Initialize MediaPipe hands module
mpHands = mp.solutions.hands
hands = mpHands.Hands()  # Default settings for hand tracking
mpDraw = mp.solutions.drawing_utils  # Utility to draw hand landmarks

# Variables to calculate Frames Per Second (FPS)
pTime = 0  # Previous time
cTime = 0  # Current time

# Main loop for real-time hand detection
while True:
    # Capture frame from webcam
    success, img = cap.read()

    # Convert the image from BGR to RGB (required by MediaPipe)
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Process the RGB image to detect hands
    results = hands.process(imgRGB)

    # If hands are detected
    if results.multi_hand_landmarks:
        # Iterate through each detected hand
        for handLms in results.multi_hand_landmarks:
            # Iterate through each landmark in the hand
            for id, lm in enumerate(handLms.landmark):
                # Get the dimensions of the image
                h, w, c = img.shape
                # Convert normalized landmark coordinates to pixel coordinates
                cx, cy = int(lm.x * w), int(lm.y * h)

                # Print landmark ID and coordinates
                print(id, cx, cy)

                # Draw a filled circle at the landmark position
                cv2.circle(img, (cx, cy), 15, (255, 0, 255), cv2.FILLED)

            # Draw landmarks and their connections on the hand
            mpDraw.draw_landmarks(img, handLms, mpHands.HAND_CONNECTIONS)

    # Calculate and display the FPS
    cTime = time.time()
    fps = 1 / (cTime - pTime)  # FPS calculation
    pTime = cTime

    # Display FPS on the image
    cv2.putText(img, str(int(fps)), (10, 70), cv2.FONT_HERSHEY_PLAIN, 3,
                (255, 0, 255), 3)

    # Display the image with landmarks
    cv2.imshow("Image", img)

    # Wait for 1ms before the next frame (real-time loop)
    cv2.waitKey(1)
