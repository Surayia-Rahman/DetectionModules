import cv2
import mediapipe as mp
import time
import HandTrackingModule as htm  # Custom module with handDetector class

# Initialize time variables for FPS calculation
pTime = 0
cTime = 0

# Start video capture from the webcam (0 is usually the default webcam)
cap = cv2.VideoCapture(0)

# Create a hand detector object from the custom module
detector = htm.handDetector()

while True:
    # Read a frame from the webcam
    success, img = cap.read()

    # Detect hands and draw landmarks (if any) on the image
    img = detector.findHands(img)

    # Get list of landmark positions for the first detected hand
    lmList = detector.findPosition(img)

    # If landmarks are found, print the position of landmark 4 (thumb tip)
    if len(lmList) != 0:
        print(lmList[4])  # Example: [id, x, y]

    # Calculate frames per second (FPS)
    cTime = time.time()
    fps = 1 / (cTime - pTime)
    pTime = cTime

    # Display the FPS on the image
    cv2.putText(img, str(int(fps)), (10, 70), cv2.FONT_HERSHEY_PLAIN, 3,
                (255, 0, 255), 3)

    # Show the final image with landmarks and FPS
    cv2.imshow("Image", img)

    # Wait for 1 ms between frames; needed to update the imshow window
    cv2.waitKey(1)
